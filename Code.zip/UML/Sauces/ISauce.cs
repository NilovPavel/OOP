﻿namespace UML.Sauces
{
    /// <summary>
    /// Соус
    /// </summary>
    internal interface ISauce
    {
        /// <summary>
        /// Острый
        /// </summary>
        /// <returns>Возвращает остроту сосуса</returns>
        bool IsSpicy();
    }
}