﻿// See https://aka.ms/new-console-template for more information

using UML;

Pizza pizza = new Pizza
{
};
