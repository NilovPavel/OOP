﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IncapsulationExample
{
    internal class Help
    {
        public static int Get0()
        { return 0; }

        public static int Get1() { return 1; }
        static Help()
        { }
    }
}
