﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Virtual
{
    class Dog : Animal
    {
        public override string Name 
        {
            get { return "Dog"; }
        }

        /*public override void Speak()
        {
            Console.WriteLine("Dog barks");
        }*/
    }
}
