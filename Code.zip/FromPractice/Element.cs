﻿// See https://aka.ms/new-console-template for more information
public class Element
{
    public string Name { get; set; }
    public int Value { get; set; }
}