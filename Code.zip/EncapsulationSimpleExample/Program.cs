﻿//Создание объекта
Coder coder = new Coder("Саша");

//Доступ к полю
Console.WriteLine(coder.Name);

coder.WriteCode();