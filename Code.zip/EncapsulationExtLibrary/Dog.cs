﻿namespace EncapsulationExtLibrary
{
    public class Dog : Animal
    {
    }
}
