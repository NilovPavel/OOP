﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WhatIsInheritance
{
    /// <summary>
    /// Класс-внук Animal
    /// </summary>
    internal class Tiger : Cat
    {
        public Tiger() : base()
        {
            //Иллюстрация транзитивного наследования
            //this.name = "";
            ;
        }
    }
}
